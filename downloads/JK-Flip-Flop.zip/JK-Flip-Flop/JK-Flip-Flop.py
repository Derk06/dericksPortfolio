# Parent class
class LogicGate:
    def __init__(self, n):
        self.name = n
        self.output = None

    def getLabel(self):
        return self.name

    def getOutput(self):
        self.output = self.performGateLogic()
        return self.output
# -------------------------------------------------------------------------------------------------------

# Binary Gate Parent Class

class BinaryGate(LogicGate):
    def __init__(self, n):
        super(BinaryGate, self).__init__(n)

        self.pinA = None
        self.pinB = None

    def getPinA(self):
        if self.pinA == None:
            return int(input("Enter Pin A input for gate "+self.getLabel()+"--> "))
        else:
            return self.pinA.getFrom().getOutput()

    def getPinB(self):
        if self.pinB == None:
            return int(input("Enter Pin B input for gate "+self.getLabel()+"--> "))
        else:
            return self.pinB.getFrom().getOutput()

    def setNextPin(self, source):
        if self.pinA == None:
            self.pinA = source
        else:
            if self.pinB == None:
                self.pinB = source
            else:
                print("Cannot Connect: NO EMPTY PINS on this gate")

# ----------------------------------------------------------------------------------------------------------

# Unary Gate Parent Class

class UnaryGate(LogicGate):
    def __init__(self, n):
        LogicGate.__init__(self, n)

        self.pin = None

    def getPin(self):
        if self.pin == None:
            return int(input("Enter Pin input for gate "+self.getLabel()+"--> "))
        else:
            return self.pin.getFrom().getOutput()

    def setNextPin(self, source):
        if self.pin == None:
            self.pin = source
        else:
            print("Cannot Connect: NO EMPTY PINS on this gate")

# -----------------------------------------------------------------------------------------------------------------

# Gate-codes

class AndGate(BinaryGate):
    def __init__(self, n):
        BinaryGate.__init__(self, n)

    def performGateLogic(self):

        a = self.getPinA()
        b = self.getPinB()
        if a == 1 and b == 1:
            return 1
        else:
            return 0

class NandGate(AndGate):

    def performGateLogic(self):
        if super().performGateLogic() == 1:
            return 0
        else:
            return 1

class OrGate(BinaryGate):
    def __init__(self, n):
        BinaryGate.__init__(self, n)

    def performGateLogic(self):

        a = self.getPinA()
        b = self.getPinB()
        if a == 1 or b == 1:
            return 1
        else:
            return 0

class NorGate(OrGate):

    def performGateLogic(self):
        if super().performGateLogic() == 1:
            return 0
        else:
            return 1

class NotGate(UnaryGate):
    def __init__(self, n):
        UnaryGate.__init__(self, n)

    def performGateLogic(self):
        if self.getPin() == 1:
            return 0
        else:
            return 1

class JKFlipFlop(BinaryGate):
    def __init__(self, n):
        BinaryGate.__init__(self, n)
        self.state = 0 #previous output
        self.qn = 0 #next output
        self.visited = False

    def performGateLogic(self):
        if not self.visited:
            self.state = self.qn
            self.visited = True
            j = self.getPinA()
            k = self.getPinB()

            if self.state == 0 and j == 0:
                self.qn = 0
            elif self.state == 0 and j == 1:
                self.qn = 1
            elif self.state == 1 and k == 0:
                self.qn = 1
            elif self.state == 1 and k == 1:
                self.qn = 0

        return self.state

# Switch for circuit0

class Switch(UnaryGate):
    def __init__(self, n):
        UnaryGate.__init__(self, n)
        self.output = None

    def performGateLogic(self):
        if self.output == None:
            self.output = int(input("What is the value of the switch?"))
        return self.output

class Constant(UnaryGate):
    def __init__(self, n):
        UnaryGate.__init__(self, n)

    def performGateLogic(self):
        return 1

# --------------------------------------------------------------------------------------------------

# Connector class to connect gates to other gates

class Connector:
    def __init__(self, fgate, tgate):
        self.fromgate = fgate
        self.togate = tgate

        tgate.setNextPin(self)

    def getFrom(self):
        return self.fromgate

    def getTo(self):
        return self.togate

# ------------------------------------------------------------------------------------------------------------

# Logic Circuit Input

def main():
    JKA = JKFlipFlop("JKA")  # Produces output of Not Q
    JKB = JKFlipFlop("JKB")  # Produces output of Q
    AND1 = AndGate("AND1")
    NOT1 = NotGate("NOT1")
    AND2 = AndGate("AND2")
    AND3 = AndGate("AND3")
    NOT2 = NotGate("NOT2")
    Constant1 = Constant("Power")
    Switch1 = Switch("Switch1")
    C1 = Connector(Switch1, AND1)
    C2 = Connector(JKB, AND1)
    C3 = Connector(Switch1, NOT1)
    C4 = Connector(AND1, JKA)
    C5 = Connector(NOT1, JKA)
    C8 = Connector(NOT2, AND2)
    C6 = Connector(Switch1, AND2)
    C7 = Connector(AND2, JKB)
    C9 = Connector(Constant1, JKB)
    C11 = Connector(JKA, NOT2)
    C12 = Connector(NOT2, AND3)
    C10 = Connector(JKB, AND3)
    while True:
        Switch1.output = int(input("Button Pressed? "))
        print(AND3.getOutput())
        JKA.visited = False
        JKB.visited = False

main()
