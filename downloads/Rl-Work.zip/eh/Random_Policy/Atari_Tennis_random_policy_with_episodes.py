import gym
from gym.wrappers.monitoring.video_recorder import VideoRecorder

training = 'training.mp4'

env = gym.make("ALE/Tennis-v5", render_mode="human")
video = VideoRecorder(env, training)
num_episodes = 100
num_timesteps = 50

for i in range(num_episodes):
    Return = 0
    state = env.reset()
    video.capture_frame()
    for t in range(num_timesteps):
        env.render()
        random_action = env.action_space.sample()
        next_state, reward, done, _, info = env.step(random_action)
        Return = Return + reward

        if done:
            break
    if i%10==0:
        print(f'Episode {i}, Return {Return}')

video.close()
env.close()