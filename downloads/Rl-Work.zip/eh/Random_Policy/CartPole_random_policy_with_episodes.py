import gym
import pygame

env = gym.make("CartPole-v1", render_mode="human")

num_episode = 100
num_timestep = 50

for i in range(num_episode):
    Return = 0
    state = env.reset()
    for t in range(num_timestep):
        env.render()
        random_action = env.action_space.sample()
        next_state, reward, done, _, info = env.step(random_action)
        Return = Return + reward
        if done:
            break
    if i%10==0:
        print(f'Episode: {i}, Return: {Return}')

env.close()