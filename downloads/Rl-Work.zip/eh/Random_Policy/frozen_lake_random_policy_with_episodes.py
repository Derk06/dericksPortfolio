import gym
import pygame
from time import sleep
env = gym.make("FrozenLake-v1", is_slippery=False, render_mode="human")

num_episodes = 10
num_timesteps = 20

for i in range(num_episodes):
    state = env.reset()
    print(f'Episode {i} :')
    env.render()

    for t in range(num_timesteps):
        random_action = env.action_space.sample()
        next_state, reward, done, _, info = env.step(random_action)
        print(f"Timestep {t + 1} :")
        env.render()
        if done:
            break

env.close()