import cv2
from cvzone.FaceMeshModule import FaceMeshDetector

cap = cv2.VideoCapture(0)
detector = FaceMeshDetector(maxFaces=1)

def click_event(event, x, y, faces, detector):
        if event == cv2.EVENT_LBUTTONDOWN and faces[0]:
            lstOfPoints = [detector.findDistance(faces[0][i], (x, y))[0] for i in range(0, 468)]
            print(lstOfPoints.index(min(lstOfPoints)))

while True:
        _, img = cap.read()
        img, faces = detector.findFaceMesh(img, draw=False)
        if faces:
            face = faces[0]
            for i in range(0, 468):
                    cv2.circle(img, (face[i][0], face[i][1]), 1, (0, 255, 0), cv2.FILLED)
            cv2.imshow("Image", img)
            cv2.setMouseCallback('Image', lambda event, x , y, flags, params :click_event(event, x, y, faces, detector))
            cv2.waitKey(1)
        else:
            cv2.imshow("Image", img)
            cv2.waitKey(1)