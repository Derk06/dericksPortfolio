import cv2
import cvzone
from cvzone.PoseModule import PoseDetector

cap = cv2.VideoCapture(0)
detector = PoseDetector()
while True:
    success, img = cap.read()
    detector.findPose(img)
    lmList, bboxInfo = detector.findPosition(img)

    if bboxInfo:
        pointLeft = lmList[12][0:2]
        pointRight = lmList[11][0:2]

        w, _, _ = detector.findDistance(pointLeft, pointRight)
        W = 37.45

        # We are finding the focal length
        #d = 80
        #f = (w*d)/W
        #print(f)

        # Finding distance
        f = 715
        d = (W * f) / w

        cvzone.putTextRect(img, f'Depth: {int(d)}cm',
                           (lmList[10][0] - 100, lmList[10][1] - 50),
                           scale=2)

    cv2.imshow("Image", img)
    cv2.waitKey(1)

