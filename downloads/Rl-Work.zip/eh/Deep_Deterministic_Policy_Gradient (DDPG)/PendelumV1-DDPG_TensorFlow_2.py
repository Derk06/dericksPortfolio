# Deep Deterministic Policy Gradient (DDPG) Implementation - Keras Pendulum Implementation from amifunny

# Team, K. (2020). Keras documentation: Deep Deterministic Policy Gradient (DDPG). Keras.io.
# https://keras.io/examples/rl/ddpg_pendulum/

# Overview:
# This code implements the Deep Deterministic Policy Gradient (DDPG) algorithm, an actor-critic,
# model-free algorithm used to solve continuous action space reinforcement learning problems.
# The algorithm involves training two neural networks: the actor and the critic, which work together
# to learn optimal policies for the agent.


# Quick Theory:
# Just like the Actor-Critic method, we have two networks:
# Actor - It proposes an action given a state.
# Critic - It predicts if the action is good (positive value) or bad (negative value) given a state and an action.
# DDPG uses two more techniques not present in the original DQN:
# First, it uses two Target networks.
# Why? Because it adds stability to training. In short, we are learning from estimated targets and Target networks are
# updated slowly, hence keeping our estimated targets stable.
# Conceptually, this is like saying, "I have an idea of how to play this well, I'm going to try it out for a bit until
# I find something better", as opposed to saying "I'm going to re-learn how to play this entire game after every move".


# Environment Setup:
# We use the OpenAI Gym's "Pendulum-v1" environment, which provides a continuous action space and a state space.
# The goal is to learn policies to swing the pendulum upright and keep it balanced.


# Actor-Critic Architecture:
# - Actor Network: Maps states to actions. The actor network determines the action to take given the current state.

# - Critic Network: Maps state-action pairs to Q-values. The critic network evaluates how good the action taken by the
#                   actor is, given the current state.


# Exploration Strategy:
# Since we are using a deterministic policy, we need to take
# care of the exploration-exploitation dilemma, because we know that a deterministic
# policy always selects the same action and doesn't explore new actions, unlike a
# stochastic policy, which selects different actions based on the probability distribution over the action space.
# Okay, how can we explore new actions while using a deterministic policy? Note that
# DDPG is designed for an environment where the action space is continuous. Thus,
# we are using a deterministic policy in the continuous action space.
# Unlike the discrete action space, in the continuous action space, we have continuous
# values. So, to explore new actions, we can just add some noise N to the action
# produced by the actor network since the action is a continuous value. We generate
# this noise using a process called the Ornstein-Uhlenbeck random process. So, our
# modified action can be represented as: a = μφ(s) + N
# For example, say the action μφ(s) produced by the actor network is 13. Suppose the
# noise N is 0.1, then our action becomes a = 13+0.1 = 13.1.

# Replay Buffer:
# We use a replay buffer to store experience tuples (s,a,r,s'). The buffer breaks the correlation between consecutive
# experiences by sampling random batches of experiences for training.


# Target Networks:
# We maintain target networks for both the actor and the critic. These networks are slowly updated to match the
# weights of the original networks. This helps stabilize training.


# Hyperparameters:
# - Learning Rates: For actor and critic optimizers.

# - Discount Factor (gamma): A number that discounts future rewards. You can think of this number as a measure of how
#                            short-sighted vs far-sighted the agent is when taking a decision.
#                            A discount factor of 0 means the agent only considers immediate rewards,
#                            while a value of 1, means projecting its decisions all the way to infinity.
#                            The closer this value is from 0, the less it looks ahead.

# - Soft Update Parameter (tau): For updating target networks.


# WorkFlow:
# 1. Initialization
#   - Initialize the actor and critic networks along with their target networks.
#   - Initialize the replay buffer and the noise process.

# 2. Training Loop
# For each episode:
#   - Reset the environment and initialize variables.
#   - For each time step:
#       - Use the actor network and policy function to select an action, adding exploration noise.
#       - Execute the action in the environment to get the next state, reward, and done flag.
#       - Store the experience tuple in the replay buffer.
#       - Sample a random batch of experiences from the buffer.
#       - Update the critic network using the sampled experiences.
#       - Update the actor network using the sampled experiences.
#       - Soft update the target networks.
#   - Store the episodic reward.

# 3. Performance Tracking:
#   - Track and plot the average episodic rewards to monitor training performance.

# Detailed Explanation and Mathmatics:

# Ornstein-Uhlenbeck Process (OUActionNoise)
#   - Generates noise for exploration: dxt = θ(μ − xt)dt + σdWt
#     This ensures that the noise added to the actions it helps the agent explore by slightly altering the actions it
#     takes. Since DDPG uses a deterministic policy, the same state always leads to the same action. Adding noise
#     introduces randomness, allowing the agent to try different actions in similar situations.
#     This helps the agent discover potentially better actions and prevents it from learning bad behaviours.

# Replay Buffer (Buffer Class)
# Stores experiences for training:
#   - Experience Tuples: (s,a,r,s')
#   - Buffer Capacity: Maximum number of experiences to store.
#   - Batch Size: Number of experiences to sample for training.

# Update Function:


#------------------------------------------------------EXAMPLE_CODE------------------------------------------------#

import os

os.environ["KERAS_BACKEND"] = "tensorflow"

import keras
from keras import layers

import tensorflow as tf
import gym
import numpy as np
import matplotlib.pyplot as plt

env = gym.make("Pendulum-v1", render_mode="human")

observation_space = env.observation_space
print(f"Observation Space ->  {observation_space}")
num_states = env.observation_space.shape[0]
print(f"Size of State Space ->  {num_states}")
print("-----------------------------------------------------------------------------")
action_space = env.action_space
print(f"Action Space ->  {action_space}")
num_actions = env.action_space.shape[0]
print(f"Size of Action Space ->  {num_actions}")
print("-----------------------------------------------------------------------------")
upper_bound = env.action_space.high[0]
lower_bound = env.action_space.low[0]
print(f"Max Value of Action ->  {upper_bound}")
print(f"Min Value of Action ->  {lower_bound}")

# Output:
# Size of State Space ->  3
# Size of Action Space ->  1
# Max Value of Action ->  2.0
# Min Value of Action ->  -2.0

# To implement better exploration by the Actor network, we use Ornstein-Uhlenbeck
# process for generating noise. It samples noise from a normal distribution.
class OUActionNoise:
    def __init__(self, mean, std_deviation, theta=0.15, dt=1e-2, x_initial=None):
        self.theta = theta
        self.mean = mean
        self.std_dev = std_deviation
        self.dt = dt
        self.x_initial = x_initial
        self.reset()

    def __call__(self):
        # Concept: This is used to generate noise for exploration in action space.
        # Equation: dxt = θ(μ − xt)dt + σdWt
        # Formula taken from https://www.wikipedia.org/wiki/Ornstein-Uhlenbeck_process
        x = (
            self.x_prev
            + self.theta * (self.mean - self.x_prev) * self.dt
            + self.std_dev * np.sqrt(self.dt) * np.random.normal(size=self.mean.shape)
        )
        # Store x into x_prev
        # Makes next noise dependent on current one
        # Making the next noise depend on the current noise helps create smoother, more gradual changes in actions.
        # This is important because it makes the agent's behavior more realistic and stable.
        # Sudden, big changes in actions can make learning harder and less effective.
        # By using this kind of noise, the agent explores more effectively and learns better.
        self.x_prev = x
        return x

    def reset(self):
        if self.x_initial is not None:
            self.x_prev = self.x_initial
        else:
            self.x_prev = np.zeros_like(self.mean)


# The Buffer class implements Experience Replay
# The buffer stores experiences (state, action, reward, next_state) which are later sampled for training.

# Critic loss - Mean Squared Error of y - Q(s, a) where y is the expected return as seen by the Target network,
# and Q(s, a) is action value predicted by the Critic network. y is a moving target that the critic model tries to
# achieve; we make this target stable by updating the Target model slowly.

# Actor loss - This is computed using the mean of the value given by the Critic network for the actions taken by the
# Actor network. We seek to maximize this quantity.
# Hence we update the Actor network so that it produces actions that get the maximum predicted value as seen by the
# Critic, for a given state

class Buffer:
    def __init__(self, buffer_capacity=100000, batch_size=64):
        # Number of "experiences" to store at max
        self.buffer_capacity = buffer_capacity
        # Num of tuples to train on.
        self.batch_size = batch_size

        # Its tells us num of times record() was called.
        self.buffer_counter = 0

        # Stores experiences to be used for training the networks
        # Instead of list of tuples as the experience.replay
        # We use different np.arrays for each tuple element
        self.state_buffer = np.zeros((self.buffer_capacity, num_states))
        self.action_buffer = np.zeros((self.buffer_capacity, num_actions))
        self.reward_buffer = np.zeros((self.buffer_capacity, 1))
        self.next_state_buffer = np.zeros((self.buffer_capacity, num_states))

    # Takes (s,a,r,s') observation tuple as input
    def record(self, obs_tuple):
        # Set index to zero if buffer_capacity is exceeded, replacing old records
        index = self.buffer_counter % self.buffer_capacity

        self.state_buffer[index] = obs_tuple[0]
        self.action_buffer[index] = obs_tuple[1]
        self.reward_buffer[index] = obs_tuple[2]
        self.next_state_buffer[index] = obs_tuple[3]

        self.buffer_counter += 1

    # Eager execution is turned on by default in TensorFlow 2. Decorating with tf.function allows
    # TensorFlow to build a static graph out of the logic and computations in our function.
    # This provides a large speed-up for blocks of code that contain many small TensorFlow operations such as this one.
    @tf.function
    def update(
        self,
        state_batch,
        action_batch,
        reward_batch,
        next_state_batch,
    ):
        # Update Critic
        with tf.GradientTape() as tape:
            # Compute the target Q-value
            # Equation: y = r + yQ'[s', μ'(s')|θ^(Q′)]
            target_actions = target_actor(next_state_batch, training=True)
            y = reward_batch + gamma * target_critic(
                [next_state_batch, target_actions], training=True
            )

            # Get the predicted Q-value
            # Equation: Q(s,a|θ^Q)
            critic_value = critic_model([state_batch, action_batch], training=True)

            # Compute the loss as the mean squared error
            # Equation: Critic_Loss = E[(y-Q(s,a|θ^Q))^2]
            critic_loss = keras.ops.mean(keras.ops.square(y - critic_value))

        # Compute the gradients for the Critic network
        # Equation: ∇_θ^Q * L_critic
        critic_grad = tape.gradient(critic_loss, critic_model.trainable_variables)

        # Apply the gradients to the Critic network
        # Equation: θ^Q ← θ^Q +α∇_θ^Q * L_actor
        critic_optimizer.apply_gradients(
            zip(critic_grad, critic_model.trainable_variables)
        )

        # Update Actor
        with tf.GradientTape() as tape:
            # Get the actions predicted by the Actor network
            # Equation: a = π(s∣θ^π)
            actions = actor_model(state_batch, training=True)

            # Get the Q-value for these actions
            # Equation: Q(s,a|θ^Q)
            critic_value = critic_model([state_batch, actions], training=True)

            # Compute the loss (negative of the Q-value)
            # Equation: actor_loss = -E[Q(s,μ(s|θ^π)|θ^Q)]
            actor_loss = -keras.ops.mean(critic_value)

        # Compute the gradients for the Actor network
        # Equation: ∇_θ^π * L_actor
        actor_grad = tape.gradient(actor_loss, actor_model.trainable_variables)

        # Apply the gradients to the Actor network
        # Equation: θ^π ← θ^π +α∇_θ^π * L_actor
        actor_optimizer.apply_gradients(
            zip(actor_grad, actor_model.trainable_variables)
        )

    # We compute the loss and update parameters
    # The learn function is primarily responsible for orchestrating the process of sampling experiences from the
    # replay buffer, converting them into tensors, and calling the update function to adjust
    # the Actor and Critic networks.
    def learn(self):
        # Get sampling range: Determine the range from which to sample experiences. This is the minimum of the
        # current number of experiences in the buffer (buffer_counter) and the maximum buffer capacity (buffer_capacity)
        record_range = min(self.buffer_counter, self.buffer_capacity)

        # Randomly sample indices: Randomly select batch_size indices from the available experiences
        batch_indices = np.random.choice(record_range, self.batch_size)

        # Convert to tensors: Convert the sampled experiences
        # (states, actions, rewards, next states) into tensors for TensorFlow operations.
        state_batch = keras.ops.convert_to_tensor(self.state_buffer[batch_indices])
        action_batch = keras.ops.convert_to_tensor(self.action_buffer[batch_indices])
        reward_batch = keras.ops.convert_to_tensor(self.reward_buffer[batch_indices])
        reward_batch = keras.ops.cast(reward_batch, dtype="float32")
        next_state_batch = keras.ops.convert_to_tensor(
            self.next_state_buffer[batch_indices]
        )

        # Pass the sampled and converted batches to the update function,
        # which updates the Actor and Critic networks based on these batches.
        self.update(state_batch, action_batch, reward_batch, next_state_batch)


# This update target parameters slowly
# Based on rate `tau`, which is much less than one.
def update_target(target, original, tau):
    target_weights = target.get_weights()
    original_weights = original.get_weights()

    for i in range(len(target_weights)):
        # Used to slowly update the target networks
        # Equation: θ′ = τθ+(1−τ)θ′
        # where:
        # - θ′ represents the weights of the target network.
        # - θ represents the weights of the original (main) network.
        # - τ is a parameter that controls the rate of the update
        target_weights[i] = original_weights[i] * tau + target_weights[i] * (1 - tau)

    target.set_weights(target_weights)

# The Actor network generates actions, and the Critic network evaluates them.
# Here we define the Actor and Critic networks. These are basic Dense models with ReLU activation.
# Note: We need the initialization for last layer of the Actor to be between -0.003 and 0.003 as this prevents us from
# getting 1 or -1 output values in the initial stages, which would squash our gradients to zero,
# as we use the tanh activation
def get_actor():
    # Initialize weights between -3e-3 and 3-e3
    last_init = keras.initializers.RandomUniform(minval=-0.003, maxval=0.003)

    inputs = layers.Input(shape=(num_states,))
    out = layers.Dense(256, activation="relu")(inputs)
    out = layers.Dense(256, activation="relu")(out)
    outputs = layers.Dense(1, activation="tanh", kernel_initializer=last_init)(out)

    # Our upper bound is 2.0 for Pendulum.
    outputs = outputs * upper_bound
    model = keras.Model(inputs, outputs)
    return model


def get_critic():
    # State as input
    state_input = layers.Input(shape=(num_states,))
    state_out = layers.Dense(16, activation="relu")(state_input)
    state_out = layers.Dense(32, activation="relu")(state_out)

    # Action as input
    action_input = layers.Input(shape=(num_actions,))
    action_out = layers.Dense(32, activation="relu")(action_input)

    # Both are passed through separate layer before concatenating
    concat = layers.Concatenate()([state_out, action_out])

    out = layers.Dense(256, activation="relu")(concat)
    out = layers.Dense(256, activation="relu")(out)
    outputs = layers.Dense(1)(out)

    # Outputs single value for give state-action
    model = keras.Model([state_input, action_input], outputs)

    return model


# The policy function is responsible for determining the action that the agent should take given the current state.
# This function uses the Actor network to generate actions and adds noise for exploration
def policy(state, noise_object):

    # The Actor network takes the current state as input and outputs an action.
    # The squeeze function is used to remove any dimensions of size 1 from the shape of the tensor.
    # Equation: a = μ(s∣θ^μ)
    # where μ is the policy (Actor network), s is the current state, and θ^π are the parameters of the Actor network.
    sampled_actions = keras.ops.squeeze(actor_model(state))

    # The noise object (an instance of OUActionNoise) generates noise to be added to the action for exploration.
    # This noise is sampled from an Ornstein-Uhlenbeck process, which produces temporally correlated noise
    # Equation: noise ∼ OU(μ,σ)
    # where μ is the mean and σ is the standard deviation of the noise.
    noise = noise_object()

    # The generated noise is added to the action output by the Actor network. This promotes exploration by the agent.
    # Equation: a_noise = a + noise
    sampled_actions = sampled_actions.numpy() + noise

    # The action is clipped to ensure it stays within the bounds defined by the environment's action space.
    # This ensures the action is valid and executable in the environment.
    # Equation: a_legal = clip(a_noise, a_min, a_max)
    # where a_min and a_max are the minimum and maximum allowable action values, respectively
    legal_action = np.clip(sampled_actions, lower_bound, upper_bound)

    return [np.squeeze(legal_action)]

# Training hyperparameters
std_dev = 0.2
ou_noise = OUActionNoise(mean=np.zeros(1), std_deviation=float(std_dev) * np.ones(1))

actor_model = get_actor()
critic_model = get_critic()

target_actor = get_actor()
target_critic = get_critic()

# Making the weights equal initially
target_actor.set_weights(actor_model.get_weights())
target_critic.set_weights(critic_model.get_weights())

# Learning rate for actor-critic models
critic_lr = 0.002
actor_lr = 0.001

critic_optimizer = keras.optimizers.Adam(critic_lr)
actor_optimizer = keras.optimizers.Adam(actor_lr)

total_episodes = 100
# Discount factor for future rewards
gamma = 0.99
# Used to update target networks
tau = 0.005

buffer = Buffer(50000, 64)

# Now we implement our main training loop, and iterate over episodes. We sample actions using policy()
# and train with learn() at each time step, along with updating the Target networks at a rate tau.

# To store reward history of each episode
ep_reward_list = []
# To store average reward history of last few episodes
avg_reward_list = []

# Takes about 4 min to train
for ep in range(total_episodes):
    prev_state, _ = env.reset()
    episodic_reward = 0

    while True:
        # Convert the state to a tensor and expand its dimensions to match the expected input shape for the networks.
        tf_prev_state = keras.ops.expand_dims(
            keras.ops.convert_to_tensor(prev_state), 0
        )

        # Use the policy function to sample an action, adding exploration noise
        action = policy(tf_prev_state, ou_noise)

        # Receive state and reward from environment
        state, reward, done, truncated, _ = env.step(action)

        # Record the experience tuple (s,a,r,s′) in the replay buffer.
        buffer.record((prev_state, action, reward, state))

        # Add the observed reward to episodic_reward
        episodic_reward += reward

        # Sample a batch of experiences from the buffer and update the Actor and Critic networks
        buffer.learn()

        # Perform a soft update of the target Actor and Critic networks
        update_target(target_actor, actor_model, tau)
        update_target(target_critic, critic_model, tau)

        # End this episode when `done` or `truncated` is True
        if done or truncated:
            break

        prev_state = state

    ep_reward_list.append(episodic_reward)

    # Mean of last 40 episodes
    avg_reward = np.mean(ep_reward_list[-40:])
    print(f"Episode * {ep} * Avg Reward is ==> {avg_reward}")
    avg_reward_list.append(avg_reward)

# Plotting graph
# Episodes versus Avg. Rewards
plt.plot(avg_reward_list)
plt.xlabel("Episode")
plt.ylabel("Avg. Episodic Reward")
plt.title("Episodes versus Avg. Rewards")
plt.show()