import numpy as np
import tensorflow as tf
import tensorflow.keras as keras
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
import os
import gym
from utils import plot_learning_curve
import time
import gc

# Twin Delayed DDPG (TD3) Implementation

# Overview:
# This code implements the Twin Delayed DDPG (TD3) algorithm, an extension of the DDPG algorithm.
# TD3 solves the overestimation bias in DDPG and introduces several modifications to improve the stability and
# performance of the DDPG algorithm. The TD3 algorithm involves training multiple neural networks:
# two critic networks, one actor network, and their corresponding target networks.

# Quick Theory:
# TD3 extends DDPG by:
# 1. Clipped Double Q-learning: Uses the minimum value between two critic networks to reduce overestimation bias.
# 2. Delayed Policy Updates: Updates the policy (actor network) less frequently than the Q-function (critic networks).
# 3. Target Policy Smoothing: Adds noise to the target policy to make it harder for the policy to exploit Q-function errors.

# Environment Setup:
# We use the OpenAI Gym's "BipedalWalker-v3" environment, which provides a continuous action space and a state space.
# The goal for the agent to learn the policy of not letting the hull touch the ground and run to the end of the map.

# Actor-Critic Architecture:
# - Actor Network: Maps states to actions. The actor network determines the action to take given the current state.
# - Critic Networks: Map state-action pairs to Q-values. The critic networks evaluate how good the action taken by the
#                    actor is, given the current state. TD3 uses two critic networks to mitigate overestimation bias.

# Exploration Strategy:
# TD3 uses a deterministic policy for action selection. To encourage exploration, noise is added to the action during
# training. The noise is typically sampled from a Gaussian distribution.

# Replay Buffer:
# A replay buffer is used to store experience tuples (state, action, reward, next_state, done). The buffer breaks the
# correlation between consecutive experiences by sampling random batches of experiences for training.

# Target Networks:
# Target networks for both the actor and the critics are maintained. These networks are slowly updated to match the
# weights of the original networks, which helps stabilize training.

# Hyperparameters:
# - Learning Rates: For actor and critic optimizers.
# - Discount Factor (gamma): Discounts future rewards.
# - Soft Update Parameter (tau): For updating target networks.
# - Noise: For exploration.


class ReplayBuffer:
    def __init__(self, max_size, input_shape, n_actions):
        self.mem_size = max_size
        self.mem_cntr = 0
        self.state_memory = np.zeros((self.mem_size, *input_shape))
        self.new_state_memory = np.zeros((self.mem_size, *input_shape))
        self.action_memory = np.zeros((self.mem_size, n_actions))
        self.reward_memory = np.zeros(self.mem_size)
        self.terminal_memory = np.zeros(self.mem_size, dtype=np.bool_)

    def store_transition(self, state, action, reward, next_state, done):
        index = self.mem_cntr % self.mem_size
        self.state_memory[index] = state
        self.new_state_memory[index] = next_state
        self.action_memory[index] = action
        self.reward_memory[index] = reward
        self.terminal_memory[index] = done

        self.mem_cntr += 1

    def sample_buffer(self, batch_size):
        max_mem = min(self.mem_cntr, self.mem_size)

        batch = np.random.choice(max_mem, batch_size)

        states = self.state_memory[batch]
        next_state = self.new_state_memory[batch]
        actions = self.action_memory[batch]
        rewards = self.reward_memory[batch]
        dones = self.terminal_memory[batch]

        return states, actions, rewards, next_state, dones

class CriticNetwork(keras.Model):
    def __init__(self, fc1_dims, fc2_dims, name, chkpt_dir='tmp/td3'):
        super(CriticNetwork, self).__init__()
        self.fc1_dims = fc1_dims
        self.fc2_dims = fc2_dims
        self.model_name = name
        self.checkpoint_dir = chkpt_dir
        self.checkpoint_file = os.path.join(self.checkpoint_dir, name+'_td3.weights.h5')

        self.fc1 = Dense(self.fc1_dims, activation="relu")
        self.fc2 = Dense(self.fc2_dims, activation="relu")
        self.q = Dense(1, activation=None)

    def call(self, state, action):
        q1_action_value = self.fc1(tf.concat([state, action], axis=1))
        q1_action_value = self.fc2(q1_action_value)

        q = self.q(q1_action_value)

        return q

class ActorNetwork(keras.Model):
    def __init__(self, fc1_dims, fc2_dims, n_actions, name, chkpt_dir="tmp/td3"):
        super(ActorNetwork, self).__init__()
        self.fc1_dims = fc1_dims
        self.fc2_dims = fc2_dims
        self.n_actions = n_actions
        self.model_name = name
        self.checkpoint_dir = chkpt_dir
        self.checkpoint_file = os.path.join(self.checkpoint_dir, name+'_td3.weights.h5')

        self.fc1 = Dense(self.fc1_dims, activation="relu")
        self.fc2 = Dense(self.fc2_dims, activation="relu")
        self.mu = Dense(self.n_actions, activation="tanh")

    def call(self, state):
        prob = self.fc1(state)
        prob = self.fc2(prob)

        mu = self.mu(prob)

        return mu

class Agent:
    def __init__(self, alpha, beta, input_dims, tau, env, gamma=0.99, update_actor_interval=2, warmup=1000, n_actions=2,
                 max_size=1000000, layer1_size=400, layer2_size=300, batch_size=300, noise=0.1):
        self.gamma = gamma
        self.tau = tau
        self.max_action = env.action_space.high[0]
        self.min_action = env.action_space.low[0]
        self.memory = ReplayBuffer(max_size, input_dims, n_actions)
        self.batch_size = batch_size
        self.learn_step_cntr = 0
        self.time_step = 0
        self.warmup = warmup
        self.n_actions = n_actions
        self.update_actor_iter = update_actor_interval

        self.actor = ActorNetwork(layer1_size, layer2_size, n_actions=n_actions, name='actor')

        self.critic_1 = CriticNetwork(layer1_size, layer2_size, name='critic_1')
        self.critic_2 = CriticNetwork(layer1_size, layer2_size, name='critic_2')

        self.target_actor = ActorNetwork(layer1_size, layer2_size, n_actions=n_actions, name='target_actor')

        self.target_critic_1 = CriticNetwork(layer1_size, layer2_size, name='target_critic_1')
        self.target_critic_2 = CriticNetwork(layer1_size, layer2_size, name='target_critic_2')

        self.actor.compile(optimizer=Adam(learning_rate=alpha), loss='mean')
        self.critic_1.compile(optimizer=Adam(learning_rate=beta), loss='mean_squared_error')
        self.critic_2.compile(optimizer=Adam(learning_rate=beta), loss='mean_squared_error')

        self.target_actor.compile(optimizer=Adam(learning_rate=alpha), loss='mean')
        self.target_critic_1.compile(optimizer=Adam(learning_rate=beta), loss='mean_squared_error')
        self.target_critic_2.compile(optimizer=Adam(learning_rate=beta), loss='mean_squared_error')

        self.noise = noise
        self.update_network_parameters(tau=1)


    def choose_action(self, observation):
        if self.time_step < self.warmup:
            mu = np.random.normal(scale=self.noise, size=(self.n_actions,))
        else:
            state = tf.convert_to_tensor([observation], dtype=tf.float32)
            mu = self.actor(state)[0]  # returns batch size of 1, want scalar

        mu_prime = mu + np.random.normal(scale=self.noise)

        mu_prime = tf.clip_by_value(mu_prime, self.min_action, self.max_action)

        self.time_step += 1
        return mu_prime

    def choose_greedy(self, observation):
        state = tf.convert_to_tensor([observation], dtype=tf.float32)
        mu = self.actor(state)[0]  # returns batch size of 1, want scalar

        mu_prime = mu + np.random.normal(scale=self.noise)

        mu_prime = tf.clip_by_value(mu_prime, self.min_action, self.max_action)

        self.time_step += 1
        return mu_prime

    def remember(self, state, action, reward, new_state, done):
        self.memory.store_transition(state, action, reward, new_state, done)

    def learn(self):
        if self.memory.mem_cntr < self.batch_size:
            return

        states, actions, rewards, new_states, dones = self.memory.sample_buffer(self.batch_size)

        states = tf.convert_to_tensor(states, dtype=tf.float32)
        actions = tf.convert_to_tensor(actions, dtype=tf.float32)
        rewards = tf.convert_to_tensor(rewards, dtype=tf.float32)
        new_states = tf.convert_to_tensor(new_states, dtype=tf.float32)

        with tf.GradientTape(persistent=True) as tape:
            target_actions = self.target_actor(new_states)
            target_actions = target_actions + tf.clip_by_value(np.random.normal(scale=0.2), -0.5, 0.5)

            target_actions = tf.clip_by_value(target_actions, self.min_action, self.max_action)

            q1_ = self.target_critic_1(new_states, target_actions)
            q2_ = self.target_critic_2(new_states, target_actions)

            # Shape is [batch_size, 1] want to collapse to [batch_size]
            q1_ = tf.squeeze(q1_, 1)
            q2_ = tf.squeeze(q2_, 1)

            q1 = tf.squeeze(self.critic_1(states, actions), 1)
            q2 = tf.squeeze(self.critic_2(states, actions), 1)

            critic_value_ = tf.math.minimum(q1_, q2_)

            target = rewards + self.gamma*critic_value_*(1-dones)

            critic_1_loss = keras.losses.MSE(target, q1)
            critic_2_loss = keras.losses.MSE(target, q2)

        critic_1_gradient = tape.gradient(critic_1_loss, self.critic_1.trainable_variables)
        critic_2_gradient = tape.gradient(critic_2_loss, self.critic_2.trainable_variables)

        self.critic_1.optimizer.apply_gradients(zip(critic_1_gradient, self.critic_1.trainable_variables))
        self.critic_2.optimizer.apply_gradients(zip(critic_2_gradient, self.critic_2.trainable_variables))

        self.learn_step_cntr += 1

        if self.learn_step_cntr % self.update_actor_iter != 0:
            return

        with tf.GradientTape() as tape:
            new_actions = self.actor(states)
            critic_1_value = self.critic_1(states, new_actions)
            actor_loss = -tf.math.reduce_mean(critic_1_value)

        actor_gradient = tape.gradient(actor_loss, self.actor.trainable_variables)
        self.actor.optimizer.apply_gradients(zip(actor_gradient, self.actor.trainable_variables))

        self.update_network_parameters()

    def update_network_parameters(self, tau=None):
        if tau is None:
            tau = self.tau

        weights = []
        targets = self.target_actor.weights
        for i, weight in enumerate(self.actor.weights):
            weights.append(weight * tau + targets[i] * (1-tau))
        self.target_actor.set_weights(weights)

        weights = []
        targets = self.target_critic_1.weights
        for i, weight in enumerate(self.critic_1.weights):
            weights.append(weight * tau + targets[i] * (1 - tau))
        self.target_critic_1.set_weights(weights)

        weights = []
        targets = self.target_critic_2.weights
        for i, weight in enumerate(self.critic_2.weights):
            weights.append(weight * tau + targets[i] * (1 - tau))
        self.target_critic_2.set_weights(weights)


    def save_models(self):
        print('... saving models ...')
        self.actor.save_weights(self.actor.checkpoint_file)
        self.critic_1.save_weights(self.critic_1.checkpoint_file)
        self.critic_2.save_weights(self.critic_2.checkpoint_file)
        self.target_actor.save_weights(self.target_actor.checkpoint_file)
        self.target_critic_1.save_weights(self.target_critic_1.checkpoint_file)
        self.target_critic_2.save_weights(self.target_critic_2.checkpoint_file)

    def load_models(self):
        print('... loading models ...')
        self.actor.load_weights(self.actor.checkpoint_file)
        self.critic_1.load_weights(self.critic_1.checkpoint_file)
        self.critic_2.load_weights(self.critic_2.checkpoint_file)
        self.target_actor.load_weights(self.target_actor.checkpoint_file)
        self.target_critic_1.load_weights(self.target_critic_1.checkpoint_file)
        self.target_critic_2.load_weights(self.target_critic_2.checkpoint_file)


# Check for GPU availability
physical_devices = tf.config.experimental.list_physical_devices('GPU')
print(physical_devices)
#if len(physical_devices) > 0:
    #try:
        #tf.config.experimental.set_memory_growth(physical_devices[0], True)
        #print('Using GPU for training.')
    #except:
        #print('Error initializing GPU.')

env = gym.make("BipedalWalker-v3")
observation_space = env.observation_space
print(f"Observation Space ->  {observation_space}")
num_states = env.observation_space.shape[0]
print(f"Size of State Space ->  {num_states}")
print("-----------------------------------------------------------------------------")
action_space = env.action_space
print(f"Action Space ->  {action_space}")
num_actions = env.action_space.shape[0]
print(f"Size of Action Space ->  {num_actions}")
print("-----------------------------------------------------------------------------")
upper_bound = env.action_space.high[0]
lower_bound = env.action_space.low[0]
print(f"Max Value of Action ->  {upper_bound}")
print(f"Min Value of Action ->  {lower_bound}")


agent = Agent(alpha=0.001,
              beta=0.001,
              input_dims=env.observation_space.shape,
              tau=0.005,
              env=env,
              batch_size=128,
              layer1_size=400,
              layer2_size=400,
              n_actions=env.action_space.shape[0])

n_games = 600
filename = 'plots/' + 'walker' + str(n_games) + '_games.png'
best_score = env.reward_range[0]
score_history = []
reward_threshold = -200

# ---------------------------------------------------- For Training -------------------------------------------------- #
for i in range(n_games):
    observation, _ = env.reset()
    done = False
    score = 0
    start_time = time.time()
    while not done:
        action = agent.choose_action(observation)
        observation_, reward, done, info, _ = env.step(action)
        agent.remember(observation, action, reward, observation_, done)
        agent.learn()
        gc.collect()  # Used to deallocate memory that is no longer required by the program
        score += reward
        observation = observation_

        # Calculate and print elapsed time
        current_time = time.time()
        elapsed_time = int(current_time - start_time)

        if score < reward_threshold or elapsed_time >= 180:
            done = True  # End the episode early if the reward threshold is reached
    score_history.append(score)
    avg_score = np.mean(score_history[-50:])

    if avg_score > best_score:
        best_score = avg_score
        #agent.save_models()

    print('episode ', i, 'score %.1f' % score, 'average score %.1f' % avg_score)

    tf.keras.backend.clear_session()  # Clearing the session can help free up memory that can held due to session growth

env.close()
x = [i+1 for i in range(n_games)]
plot_learning_curve(x, score_history, filename)

# -------------------------------------------------------------------------------------------------------------------- #

# ----------------------------------------------- For Viewing -------------------------------------------------------- #
# Load the trained models
#agent.load_models()

#n_episodes = 10

#for i in range(n_episodes):
    #observation, _ = env.reset()
    #env.render()
    #done = False
    #score = 0
    #start_time = time.time()
    #while not done:
        #env.render()
        #action = agent.choose_greedy(observation)
        #observation_, reward, done, _, _ = env.step(action)
        #score += reward
        #observation = observation_

        # Calculate and print elapsed time
        #current_time = time.time()
        #elapsed_time = int(current_time - start_time)

        #if elapsed_time >= 180:
            #done = True  # End the episode early if the elapsed time is too long

    #print(f'Episode {i + 1}, Score: {score:.1f}')

#env.close()
# -------------------------------------------------------------------------------------------------------------------- #