import gym
import pandas as pd
from collections import defaultdict
import random


# env = gym.make("Blackjack-v1", render_mode="human")
# Note: Visualising the environment will slow down execution time, if you want to visualise it uncomment
# the top line and comment out the bottom
env = gym.make("Blackjack-v1")

# Initialize the dictionary for storing the Q values
Q = defaultdict(float)

# Initialize the dictionary for storing the total return of the state-action pair
total_return = defaultdict(float)

# Initialize the dictionary for storing the count of the number of times a state-action pair is visited
N = defaultdict(int)

def epsilon_greedy_policy(state, Q):
    """
    Takes the state and Q value as an input and returns,
    the action to be performed in the given state
    """
    epsilon = 0.5
    if len(state) == 2:
        state_value, _ = state  # State value will look like ((num, num, bool), {}), Only want the state_value
    else:
        state_value = state  # State value will look like (num, num, bool)

    # If the sampled value is less than epsilon then we select a random action,
    # else we select the best action that has the maximum Q value
    if random.uniform(0,1) < epsilon:
        return env.action_space.sample()
    else:
        return max(list(range(env.action_space.n)), key=lambda x:Q[(state_value, x)])

num_timesteps = 100

def generate_episode(Q):
    episode = []
    state = env.reset()
    for t in range(num_timesteps):
        action = epsilon_greedy_policy(state, Q)
        next_state, reward, done, _, info = env.step(action)

        if len(state) == 2:
            state_value, _ = state  # State value will look like ((num, num, bool), {}), Only want the state_value
        else:
            state_value = state  # State value will look like (num, num, bool)

        episode.append((state_value, action, reward))

        if done:
            break

        state = next_state
    return episode

num_iterations = 10000

for i in range(num_iterations):
    # On-policy control method, we will not be given any policy as an input.
    # We initialize a random policy in the first iteration and improve the policy iteratively by computing the Q value.

    episode = generate_episode(Q)

    all_state_action_pairs = []
    rewards = []
    for s, a, r in episode:
        all_state_action_pairs.append((s, a))
        rewards.append(r)

    for t, (state, action, _) in enumerate(episode):
        if not (state, action) in all_state_action_pairs[0:t]:

            # Compute the return R of the state-action pair as the sum of rewards
            R = sum(rewards[t:])

            # Compute the return R of the state-action pair as the sum of rewards
            total_return[(state, action)] = total_return[(state, action)] + R

            # Update the number of times the state-action pair is visited
            N[(state, action)] = N[(state, action)] + 1

            # Compute the Q value by just taking the average
            Q[(state, action)] = total_return[(state, action)] / N[(state, action)]


df = pd.DataFrame(Q.items(), columns=['state_action pair', 'value'])

print(df.head(20))

env.close()