import gym
import pandas as pd
from collections import defaultdict


# env = gym.make("Blackjack-v1", render_mode="human")
# Note: Visualising the environment will slow down execution time, if you want to visualise it uncomment
# the top line and comment out the bottom
env = gym.make("Blackjack-v1")

def policy(state):
    if len(state) == 2:
        player_score = state[0][0]  # State value will look like ((num, num, bool), {}) So we double index

    else:  # When program goes through second iteration the state will only have length of 1
        player_score = state[0]  # State value will look like (num, num, bool) So we index

    if player_score > 19:
        return 0
    else:
        return 1

num_timesteps = 100

def generate_episode():
    episode = []
    state = env.reset()
    for t in range(num_timesteps):
        action = policy(state)
        next_state, reward, done, _, info = env.step(action)
        if len(state) == 2:
            state_value, _ = state  # State value will look like ((num, num, bool), {}), Only want the state_value
        else:
            state_value = state  # State value will look like (num, num, bool)
        episode.append((state_value, action, reward))

        if done:
            break

        state = next_state

    return episode

total_return = defaultdict(float)
N = defaultdict(int)

num_iterations = 10000

for i in range(num_iterations):
    episode = generate_episode()
    states, actions, rewards = zip(*episode)
    for t, state in enumerate(states):
        if state not in states[0:t]:
            R = sum(rewards[t:])
            total_return[state] = total_return[state] + R
            N[state] = N[state] + 1

total_return = pd.DataFrame(total_return.items(), columns=['state', 'total_return'])

N = pd.DataFrame(N.items(), columns=['state', 'N'])

df = pd.merge(total_return, N, on="state")

# Compute value of state as the average return: V(s) = total_return / N(s)
df['value'] = df['total_return']/df['N']

print(df.head(20))

env.close()