import gym
import pandas as pd

#env = gym.make("FrozenLake-v1", is_slippery=False, render_mode="human")
# Note: Visualising the environment will slow down execution time, if you want to visualise it uncomment
# the top line and comment out the bottom
env = gym.make("FrozenLake-v1")

def random_policy():
    return env.action_space.sample()

# Define the dictionary for storing the value of states,
V = {}

for s in range(env.observation_space.n):
    # Initialize the value of all the states to 0.0:
    V[s] = 0.0

# Initialize learning rate
alpha = 0.85

# Initialize discount factor
gamma = 0.90

num_episodes = 5000
num_timesteps = 1000

for i in range(num_episodes):
    state_unorganized = env.reset()
    state, _ = state_unorganized  # State unorganized will look like this (state, {probability}), we want state.

    for t in range(num_timesteps):
        action = random_policy()
        next_state, r, done, _, _ = env.step(action)
        # Compute the value of the state as V(s) = V(s) + α(r + y(s′) − V(s)):
        V[state] = alpha * (r + gamma * V[next_state] - V[state])

        state = next_state

        if done:
            break

df = pd.DataFrame(list(V.items()), columns=['state', 'value'])

print(df)


env.close()