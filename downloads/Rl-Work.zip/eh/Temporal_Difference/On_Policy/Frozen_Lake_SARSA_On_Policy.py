import random
import gym
import pandas as pd

#---------About-SARSA----------------#
# SARSA is an on-policy algorithm, meaning that we use a single epsilon-greedy
# policy for selecting an action in the environment and also to compute the Q value
# of the next state-action pair. The update rule of SARSA is given as follows:
# Q(s,a) = Q(s,a) + a(r + yQ(s',a') - Q(s,a))


#env = gym.make("FrozenLake-v1", is_slippery=False, render_mode="human")
# Note: Visualising the environment will slow down execution time, if you want to visualise it uncomment
# the top line and comment out the bottom
env = gym.make("FrozenLake-v1")

# define the dictionary for storing the Q value of the state-action pair
Q = {}
for s in range(env.observation_space.n):
    for a in range(env.action_space.n):
        # Initialize the Q value of all the state-action pairs to 0.0:
        Q[(s,a)] = 0.0

def epsilon_greedy(state, epsilon):
    if random.uniform(0,1) < epsilon:
        return env.action_space.sample()
    else:
        return max(list(range(env.action_space.n)), key=lambda x: Q[(state, x)])

# Initialize learning factor
alpha = 0.85

# Initialize discount factor
gamma = 0.90

# Initialize epsilon value
epsilon = 0.8

num_episodes = 5000
num_timesteps = 1000

for i in range(num_episodes):
    state_unorganized = env.reset()
    state, _ = state_unorganized

    action = epsilon_greedy(state, epsilon)
    for t in range(num_timesteps):
        next_state, reward, done, _, _ = env.step(action)

        next_action = epsilon_greedy(next_state, epsilon)

        # Compute Q value of state action pair: Q(s,a) = Q(s,a) + a(r + yQ(s',a') - Q(s,a))
        Q[(state,action)] += alpha * (reward + gamma * Q[(next_state, next_action)] - Q[state, action])

        state = next_state
        action = next_action

        if done:
            break

df = pd.DataFrame(Q.items(), columns=['state', 'value'])
print(df.head(20))

env.close()