# Building a neural network from scratch
# We will understand how the neural network learns to
# perform the XOR gate operation. The XOR gate returns 1 only when exactly only one
# of its inputs is 1, else it returns 0, as shown in Table 7.1:
# |--------------------------|
# | Inputs(x)   | Outputs(y) |
# | (x1) | (x2) |     y      |
# |   0  |  0   |     0      |
# |   0  |  1   |     1      |
# |   1  |  0   |     1      |
# |   1  |  1   |     1      |
# |--------------------------|

# --------------------------------How the network works---------------------------------------------------#
# Neural Network Structure:
# At its core, a neural network is a collection of interconnected nodes (neurons) organized into layers.
# Each neuron receives inputs, processes them using weights and biases, and produces an output.
# The XOR problem is a classic example of a problem that requires a non-linear decision boundary,
# which can be achieved by using a hidden layer with a non-linear activation function like sigmoid.

# Activation Function (Sigmoid):
# The sigmoid function S(x) = 1 / (1 + e^-x) is a smooth, non-linear function that squashes its input
# to a value between 0 and 1. This property makes it suitable for representing probabilities.
# In neural networks, the activation function introduces non-linearity, allowing the network to learn
# complex patterns in the data that would not be possible with a linear model.

# Weights and Biases Initialization:
# Weights (represented by Wxh and Why) determine the strength of connections between neurons in adjacent layers.
# Initially, these weights are randomly initialized to small values.
# Biases (represented by bh and by) are additional parameters added to each neuron that allow the network to
# fit the data better by shifting the activation function.

# Forward Propagation:
# Forward propagation is the process of calculating the output of the network for a given input.
# It involves multiplying the input by the weights, adding the bias, and applying the activation function.
# In the XOR network, forward propagation calculates the output of the hidden layer (a1) and the output layer
# (y_hat) based on the input (X) weights, and biases.

# Backward Propagation:
# Backward propagation is the process of updating the weights of the network based on the error between
# the predicted output (y_hat) and the actual output (y).
# It uses the chain rule of calculus to calculate the gradients of the loss function with respect to the weights,
# which are then used to update the weights using gradient descent.

# Cost Function (Mean Squared Error):
# The mean squared error (MSE) cost function J = (1/2) * ∑(y - y_hat)^2
# measures the average squared difference between the predicted output and the actual output.
# Minimizing the cost function during training helps the network learn to make more accurate predictions.

# Learning Rate and Training Iterations:
# The learning rate (a) controls how much the weights are updated during each iteration of training.
# A larger learning rate means larger updates, which can lead to faster convergence but may also cause instability.
# Training iterations determine how many times the network will update its weights based on the entire dataset.
# More iterations allow the network to learn more from the data, but too many iterations can lead to overfitting.

# Training Process:
# During training, the network iterates over the training data multiple times, adjusting the weights based on
# the calculated gradients.The goal is to minimize the cost function, which indicates how well the network is
# fitting the training data. This is done by updating the weights in the direction that reduces the cost function.


# --------------Code---------------- #

import numpy as np
import matplotlib.pyplot as plt

# Prepare the data as shown in the preceding XOR table
X = np.array([[0, 1], [1, 0], [1, 1], [0, 0]])
y = np.array([[1], [1], [0], [0]])

# Define the number of nodes in each layer
num_inputs = 2
num_hidden = 5
num_output = 1

# Initialize the weights and bias randomly. First, we initialize the input to hidden layer weights
Wxh = np.random.randn(num_inputs, num_hidden)
bh = np.zeros((1, num_hidden))

# Now, we initialize the hidden to output layer weights
Why = np.random.randn(num_hidden, num_output)
by = np.zeros((1, num_output))


# Define the sigmoid activation function
def sigmoid(z):
    # Sigmoid function: S(x) = 1 / (1 + e^-x)
    return 1 / (1+np.exp(-z))

# Define sigmoid derivative
def sigmoid_derivative(z):
    return np.exp(-z) / ((1+np.exp(-z))**2)

# Define forward propagation
def forward_prop(x, Wxh, Why):
    z1 = np.dot(x, Wxh) + bh
    a1 = sigmoid(z1)
    z2 = np.dot(a1, Why) + by
    y_hat = sigmoid(z2)
    return z1, a1, z2, y_hat

# Define backward propagation
def backword_prop(y_hat, z1, a1, z2):
    delta2 = np.multiply(-(y-y_hat), sigmoid_derivative(z2))
    dJ_dWhy = np.dot(a1.T, delta2)
    delta1 = np.dot(delta2, Why.T) * sigmoid_derivative(z1)
    dJ_dWxh = np.dot(X.T, delta1)

    return dJ_dWxh, dJ_dWhy

# Define the cost function
def cost_function(y, y_hat):
    J = 0.5*sum((y-y_hat)**2)

    return J

# Set the learning rate and the number of training iterations
alpha = 0.01
num_iterations = 5000

# Now start training the network
cost = []

for i in range(num_iterations):
    z1, a1, z2, y_hat = forward_prop(X, Wxh, Why)
    dJ_dWxh, dJ_dWhy = backword_prop(y_hat, z1, a1, z2)

    # Update weights
    Wxh = Wxh -alpha * dJ_dWxh
    Why = Why-alpha * dJ_dWhy

    # Compute loss
    c = cost_function(y, y_hat)

    cost.append(c)

plt.grid()
plt.plot(range(num_iterations),cost)
plt.title('Cost Function')
plt.xlabel('Training Iterations')
plt.ylabel('Cost')
plt.show()