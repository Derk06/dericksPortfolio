import random
import gym
import numpy as np
import tensorflow as tf
from collections import deque
from tensorflow.keras.layers import Dense, Activation, Flatten, Conv2D, MaxPooling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import Sequential


env = gym.make("ALE/MsPacman-v5")

state_size = (88, 80, 1)

action_size = env.action_space.n

colour = np.array([210, 164, 74]).mean()

def preprocess_state(state):
    # Crop and resize the image:
    image = state[1:176:2, ::2]

    # Convert the image to grayscale
    image = image.mean(axis=2)

    # Improve the image contrast
    image[image==colour] = 0

    # Normalize the image
    image = (image - 128) / 128 - 1

    # Reshape and return the image
    image = np.expand_dims(image.reshape(88, 80, 1), axis=0)

    return image

class DQN:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size

        # Define the replay buffer
        self.replay_buffer = deque(maxlen=5000)

        # Define the discount factor
        self.gamma = 0.9

        # Define the epsilon value
        self.epsilon = 0.8

        # Define the update rate at which we want to update the target network
        self.update_rate = 1000

        # Define the main network
        self.main_network = self.build_network()

        # Define the target network
        self.target_network = self.build_network()

        # Copy the weights of the main network to the target network
        self.target_network.set_weights(self.main_network.get_weights())

    def build_network(self):
        model = Sequential([
            # Define the first convolutional layer:
            Conv2D(32, # Represents the number of filters in that convolutional layer
                   (8,8), # Represents the size of the convolutional kernel or filter.
                   strides=4,  # Means that the convolutional kernel will move 4 pixels at a time when sliding over the input image.
                   padding='same',  # Argument ensures that the output feature map has the same spatial dimensions as the input by padding the input with zeros if necessary.
                   input_shape=self.state_size),  # Argument expects a tuple specifying the shape of a single input sample. For image data, this typically means (height, width, channels)
            Activation("relu"),

            # Define the second convolutional layer
            Conv2D(64,
                   (4,4),
                   strides=2,
                   padding='same'),
            Activation("relu"),

            # Define the third convolutional layer
            Conv2D(64,
                   (3,3),
                   strides=1,
                   padding='same'),
            Activation("relu"),

            # Flatten the feature maps obtained as a result of the third convolutional layer
            Flatten(),

            # Feed the flattened maps to the fully connected layer
            Dense(512, activation='relu'),
            Dense(self.action_size, activation='linear')
        ])

        model.compile(loss="mse",
                      optimizer=Adam())

        return model

    def store_transistion(self, state, action, reward, next_state, done):
        self.replay_buffer.append((state, action, reward, next_state, done))


    def epsilon_greedy(self, state):
        if random.uniform(0,1) < self.epsilon:
            return np.random.randint(self.action_size)
        Q_values = self.main_network.predict(state, verbose=0)
        return np.argmax(Q_values[0])

    def train(self, batch_size):
        # Sample a minibatch of transitions from the replay buffer
        minibatch = random.sample(self.replay_buffer, batch_size)

        # Compute the target value using the target network
        for state, action, reward, next_state, done in minibatch:
            if not done:
                target_Q = (reward + self.gamma * np.amax(self.target_network.predict(next_state, verbose=0)))
            else:
                target_Q = reward

            # Compute the predicted value using the main network and store the predicted value in the Q_values
            Q_values = self.main_network.predict(state, verbose=0)

            # Update the target value
            Q_values[0][action] = target_Q

            # Train the main network
            self.main_network.fit(state, Q_values, epochs=1, verbose=0)

    def update_target_network(self):
        # Updating the target network weights by copying from the main network:
        self.target_network.set_weights(self.main_network.get_weights())


# Training DQN
num_episodes = 10
num_timesteps = 10000
batch_size = 8
# Set the number of past game screens we want to consider
num_screens = 4
# Instantiate the DQN class
dqn = DQN(state_size, action_size)

for i in range(num_episodes):
    Return = 0
    # Preprocess the game screen
    entire_state = env.reset()
    state = preprocess_state(entire_state[0])

    # Initialize the time_step
    time_step = 0

    # For each step in episode
    for t in range(num_timesteps):
        # Render the environment
        # env.render()

        # Update the time_step
        time_step += 1

        # Update the target_network
        if time_step % dqn.update_rate == 0:
            dqn.update_target_network()

        # Select action
        action = dqn.epsilon_greedy(state)

        # Perform selected action
        next_state, reward, done, _, _ = env.step(action)

        # Preprocess the next state
        next_state = preprocess_state(next_state)

        # Store the transition information
        dqn.store_transistion(state, action, reward, next_state, done)

        # Update the current state to the next state
        state = next_state

        # Update the return value
        Return += reward

        # If episode is done, then print the return
        if done:
            print(done)
            print(f"Episode {i}, Return: {Return}")
            break

        # If the number of transitions in the replay buffer is greater than the batch size, then
        # train the network
        if len(dqn.replay_buffer) > batch_size:
            dqn.train(batch_size)

env.close()