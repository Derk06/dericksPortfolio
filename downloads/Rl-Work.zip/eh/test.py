import gym

env = gym.make("BipedalWalker-v3")
print(env.action_space.shape[0])