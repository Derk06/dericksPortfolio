import gym_bandits
import gym
import numpy as np

#---------------About Softmax_exploration----------------------------------#
# In the epsilon-greedy policy, we learned that we select the best arm with probability
# 1-epsilon and a random arm with probability epsilon. As you may have noticed, in
# the epsilon-greedy policy, all the non-best arms are explored equally. That is, all the
# non-best arms have a uniform probability of being selected. For example, say we
# have 4 arms and arm 1 is the best arm. Then we explore the non-best arms – [arm 2,
# arm 3, arm 4] – uniformly.
# Say arm 3 is never a good arm and it always gives a reward of 0. In this case, instead
# of exploring arm 3 again, we can spend more time exploring arm 2 and arm 4. But
# the problem with the epsilon-greedy method is that we explore all the non-best arms
# equally. So, all the non-best arms – [arm 2, arm 3, arm 4] – will be explored equally.
# To avoid this, if we can give priority to arm 2 and arm 4 over arm 3, then we can
# explore arm 2 and arm 4 more than arm 3.
# Okay, but how can we give priority to the arms? We can give priority to the arms by
# assigning a probability to all the arms based on the average reward Q. The arm that
# has the maximum average reward will have high probability, and all the non-best
# arms have a probability proportional to their average reward. This is the general idea behind the
# softmax_exploration method


env = gym.make("BanditTwoArmedHighLowFixed-v0")

# Initialize the count for storing the number of times an arm is pulled
count = np.zeros(2)

# Initialize sum_rewards for storing the sum of rewards of each arm
sum_rewards = np.zeros(2)

# Initialize Q for storing the average reward of each arm
Q = np.zeros(2)

# Set number of round (iterations)
num_rounds = 1000

# Define the softmax function with the temperature T: P↓t(a) = (exp(Q↓t(a) / T)) / (Σ↑n↓i=1 exp(Q↓t(i) / T))
def softmax(T):
    denom = 0
    for i in Q:
        exponential = np.exp(i / T)  # Calculate the exponential of the Q-value
        denom += exponential  # Add the exponential to the sum

    probs = []
    for i in Q:
        exponential_denom = np.exp(i/T)/denom
        probs.append(exponential_denom)


    # Select the arm based on the computed probability distribution of arms:
    arm = np.random.choice(env.action_space.n, p=probs)

    return arm


env.reset()

T = 50

for i in range(num_rounds):
    arm = softmax(T)
    next_state, reward, done, info = env.step(arm)
    count[arm] += 1
    sum_rewards[arm] += reward
    Q[arm] = sum_rewards[arm]/count[arm]

    T = T * 0.99

# Select the optimal arm as the one that has the maximum average reward:
print(f"The optimal arm is {np.argmax(Q)+1}")

env.close()