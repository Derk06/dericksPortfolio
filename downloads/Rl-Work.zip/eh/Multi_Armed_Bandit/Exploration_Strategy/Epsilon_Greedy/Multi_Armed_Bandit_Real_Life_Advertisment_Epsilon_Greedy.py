import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# We generate a dataset with five columns denoting the five
# advertisement banners, and we generate 100,000 rows, where the values in the rows
# will be either 0 or 1, indicating whether the advertisement banner has been clicked
# (1) or not clicked (0) by the user
df = pd.DataFrame()
for i in range(5):
    df['Banner_type_'+str(i)] = np.random.randint(0,2,100000)

num_iteration = 100000
num_banner = 5

count = np.zeros(num_banner)

sum_rewards = np.zeros(num_banner)

Q = np.zeros(num_banner)

banner_selected = []

def epsilon_greedy_policy(epsilon):
    if np.random.uniform(0,1) < epsilon:
        return np.random.choice(num_banner)
    else:
        return np.argmax(Q)

for i in range(num_iteration):
    banner = epsilon_greedy_policy(0.5)
    reward = df.values[i, banner]
    count[banner] += 1
    sum_rewards[banner] += reward
    Q[banner] = sum_rewards[banner]/ count[banner]
    banner_selected.append(banner)

print(f'The best banner is banner {np.argmax(Q)}')

labels = []
count = []
for i in range(num_banner):
    labels.append(i)
    count.append(banner_selected.count(i))

# Create a bar plot
plt.bar(labels, count)

# Add labels and title
plt.xlabel('Banner')
plt.ylabel('Count')
plt.title('Preferred Banner')

# Show the plot
plt.show()
