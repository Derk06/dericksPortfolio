import gym_bandits
import gym
import numpy as np

#---------------About Epsilon_Greedy----------------------------------#
# The epsilon-greedy policy, all the non-best arms are explored equally. That is, all the
# non-best arms have a uniform probability of being selected. For example, say we
# have 4 arms and arm 1 is the best arm. Then we explore the non-best arms – [arm 2,
# arm 3, arm 4] – uniformly.

env = gym.make("BanditTwoArmedHighLowFixed-v0")

# Initialize the count for storing the number of times an arm is pulled
count = np.zeros(2)

# Initialize sum_rewards for storing the sum of rewards of each arm
sum_rewards = np.zeros(2)

# Initialize Q for storing the average reward of each arm
Q = np.zeros(2)

# Set number of round (iterations)
num_rounds = 100

# Define the epsilon_greedy function. generate a random number from a uniform distribution.
# If the random number is less than epsilon, then we pull the random arm; else, we pull the best
# arm that has the maximum average reward.
def epsilon_greedy(epsilon):

    if np.random.uniform(0,1) < epsilon:
        return env.action_space.sample()
    else:
        return np.argmax(Q)

env.reset()

for i in range(num_rounds):
    # Select the arm based on the epsilon-greedy method
    arm = epsilon_greedy(epsilon=0.5)

    next_state, reward, done, info = env.step(arm)

    # Increment the count of the arm by 1
    count[arm] += 1

    # Update the sum of rewards of the arm
    sum_rewards[arm] += reward

    # Update the average reward of the arm
    Q[arm] = sum_rewards[arm]/count[arm]

print(Q)

# Select the optimal arm as the one that has the maximum average reward:
# a* = arg max(a) Q(a)
print(f"The optimal arm is {np.argmax(Q)+1}")

env.close()