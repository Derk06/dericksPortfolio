import gym_bandits
import gym
import numpy as np

#---------------About Upper_Confidence_Bound----------------------------------#
# we can see the confidence intervals of arm 1(0.9 to 0.2) and arm 2(0.7 to 0.5). Now,
# how can we make a decision? That is, how can we decide whether to pull arm 1 or
# arm 2? If we look closely, we can see that the confidence interval of arm 1 is large
# and the confidence interval of arm 2 is small.
# When the confidence interval is large, we are uncertain about the mean value. Since
# the confidence interval of arm 1 is large (0.2 to 0.9), we are not sure what reward we
# would obtain by pulling arm 1 because the average reward varies from as low as 0.2
# to as high as 0.9. So, there is a lot of uncertainty in arm 1 and we are not sure whether
# arm 1 gives a high reward or a low reward.
# When the confidence interval is small, then we are certain about the mean value.
# Since the confidence interval of arm 2 is small (0.5 to 0.7), we can be sure that we
# will get a good reward by pulling arm 2 as our average reward is in the range of
# 0.5 to 0.7.
# But what is the reason for the confidence interval of arm 2 being small and the
# confidence interval of arm 1 being large? At the beginning of the section, we learned
# that we played the game for 20 rounds by pulling arm 1 and arm 2 randomly and
# computed the mean reward of arm 1 and arm 2. Say arm 2 has been pulled 15 times
# and arm 1 has been pulled only 5 times. Since arm 2 has been pulled many times,
# the confidence interval of arm 2 is small and it denotes a certain mean reward. Since
# arm 1 has been pulled fewer times, the confidence interval of the arm is large and it
# denotes an uncertain mean reward. Thus, it indicates that arm 2 has been explored
# a lot more than arm 1.
# Okay, coming back to our question, should we pull arm 1 or arm 2? In UCB, we
# always select the arm that has a high upper confidence bound, so in our example,
# we select arm 1 since it has a high upper confidence bound of 0.9. But why do
# we have to select the arm that has the highest upper confidence bound? Selecting
# the arm with the highest upper bound helps us to select the arm that gives the
# maximum reward.
# But there is a small catch here. When the confidence interval is large, we will not be
# sure about the mean reward. For instance, in our example, we select arm 1 since it
# has a high upper confidence bound of 0.9; however, since the confidence interval
# of arm 1 is large, our mean reward could be anywhere from 0.2 to 0.9, and so we
# can even get a low reward. But that's okay, we still select arm 1 as it promotes
# exploration. When the arm is explored well, then the confidence interval gets
# smaller.
# As we play the game for several rounds by selecting the arm that has a high UCB,
# our confidence interval of both arms will get narrower and denote a more accurate
# mean value. For instance, after playing the game for
# several rounds, the confidence interval of both the arms becomes small, arm 1 interval is now (0.5 to 0.4)
# and arm 2 interval is now (0.7 to 0.6) which denotes
# a more accurate mean value.
# We can see that the confidence interval of both arms is small and
# we have a more accurate mean, and since in UCB we select arm that has the highest
# UCB, we select arm 2 as the best arm.

env = gym.make("BanditTwoArmedHighLowFixed-v0")

# Initialize the count for storing the number of times an arm is pulled
count = np.zeros(2)

# Initialize sum_rewards for storing the sum of rewards of each arm
sum_rewards = np.zeros(2)

# Initialize Q for storing the average reward of each arm
Q = np.zeros(2)

# Set number of round (iterations)
num_rounds = 1000

# Define the softmax function with the temperature T: P↓t(a) = (exp(Q↓t(a) / T)) / (Σ↑n↓i=1 exp(Q↓t(i) / T))
def UCB(i):
    ucb = np.zeros(2)

    # Before computing the UCB, we explore all the arms at least once, so for the first 2
    # rounds, we directly select the arm corresponding to the round number:
    if i < 2:
        return i
    else:
        # Compute UCB: UCB(a) = Q(a) + sqrt(2log(t)/N(a))
        for arm in range(2):
            ucb[arm] = Q[arm] + np.sqrt((2*np.log(sum(count))) / count[arm])

        # Select arm that has the highest upper confidence bound as the best arm
        return np.argmax(ucb)


env.reset()

for i in range(num_rounds):
    arm = UCB(i)
    next_state, reward, done, info = env.step(arm)
    count[arm] += 1
    sum_rewards[arm] += reward

    Q[arm] = sum_rewards[arm] / count[arm]

# Select the optimal arm as the one that has the maximum average reward:
print(f"The optimal arm is {np.argmax(Q)+1}")

env.close()