import gym_bandits
import gym
import numpy as np
#---------------About Thompson_Sampling----------------------------------#
# Thompson sampling (TS) is another interesting exploration strategy to overcome
# the exploration-exploitation dilemma and it is based on a beta distribution.
# The shape of the distribution is controlled by the two parameters α and β. When
# the values of α and β are the same, then we will have a symmetric distribution.
# When the value of αα is higher than ββ then we will have a probability closer to 1 than
# 0. Take the values of α = 9 and β = 2, we have a
# high probability closer to 1 than 0.
# When the value of β is higher than α then we will have a high probability closer to
# 0 than 1. Take the values of α = 2 and
# β = 9, we have a high probability closer to 0 than 1.
# We are essentially increasing the
# alpha value of the distribution of the arm if we win the game by pulling that arm,
# else we increase the beta value. If we do this repeatedly for several rounds, then we
# can learn the true distribution of the arm.

env = gym.make("BanditTwoArmedHighLowFixed-v0")

# Initialize the count for storing the number of times an arm is pulled
count = np.zeros(2)

# Initialize sum_rewards for storing the sum of rewards of each arm
sum_rewards = np.zeros(2)

# Initialize Q for storing the average reward of each arm
Q = np.zeros(2)

# Initialize the alpha value as 1 for both arms
alpha = np.ones(2)

# Initialize the beta value as 1 for both arms
beta = np.ones(2)

# Set number of round (iterations)
num_rounds = 1000

# Define the thompson_sampling function.
# As the following code shows, we randomly sample values from the beta
# distributions of both arms and return the arm that has the maximum sampled value
def thompson_sampling(alpha, beta):
    samples = []
    for i in range(2):
        sample = np.random.beta(alpha[i]+1, beta[i]+1)
        samples.append(sample)

    return np.argmax(samples)

env.reset()

for i in range(num_rounds):
    arm = thompson_sampling(alpha, beta)
    next_state, reward, done, info = env.step(arm)
    count[arm] += 1
    sum_rewards[arm] += reward
    Q[arm] = sum_rewards[arm] / count[arm]

    # If we win the game, that is, if the reward is equal to 1, then we update the value of
    # alpha to a = a + 1, else we update the value of beta to b = b + 1:
    if reward == 1:
        alpha[arm] = alpha[arm] + 1
    else:
        beta[arm] = beta[arm] + 1

# Select the optimal arm as the one that has the maximum average reward:
print(f"The optimal arm is {np.argmax(Q)+1}")
env.close()