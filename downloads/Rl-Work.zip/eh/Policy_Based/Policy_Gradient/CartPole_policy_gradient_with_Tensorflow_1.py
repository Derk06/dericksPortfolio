import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import numpy as np
import gym

# Create the cart pole environment using gym
env = gym.make('CartPole-v1')

# Get the state shape
state_shape = env.observation_space.shape[0]

# Get the number of actions
num_actions = env.action_space.n

# Set the discount factor, gamma
gamma = 0.95


# Define discount_and_normalize_rewards for computing the discounted and normalized rewards
def discount_and_normalize_rewards(episode_rewards):
    # Initialize an array for storing the discounted rewards
    discounted_rewards = np.zeros_like(episode_rewards)

    # Compute the discounted reward
    reward_to_go = 0.0
    for i in reversed(range(len(episode_rewards))):
        reward_to_go = reward_to_go * gamma + episode_rewards[i]
        discounted_rewards[i] = reward_to_go

    # Normalize and return the reward
    discounted_rewards -= np.mean(discounted_rewards)
    discounted_rewards /= np.std(discounted_rewards)
    return discounted_rewards

#----------------------------Building Policy Network------------------------------------#

# Define the placeholder for the state
state_ph = tf.placeholder(tf.float32, [None, state_shape], name="state_ph")

# Define the placeholder for the action
action_ph = tf.placeholder(tf.int32, [None, num_actions], name="action_ph")

# Define the placeholder for the discounted reward
discounted_rewards_ph = tf.placeholder(tf.float32, [None,], name="discounted_rewards")

# Define layer 1
layer1 = tf.keras.layers.Dense(32, activation=tf.nn.relu)(state_ph)

# Define layer 2
layer2 = tf.keras.layers.Dense(num_actions)(layer1)

# Obtain the probability distribution over the action space as an output of the network
prob_dist = tf.nn.softmax(layer2)

# Define the negative log policy
neg_log_policy = tf.nn.softmax_cross_entropy_with_logits_v2(logits=layer2, labels=action_ph)

# Define the loss
loss = tf.reduce_mean(neg_log_policy * discounted_rewards_ph)

# Define the train operation for minimizing the loss using the Adam optimizer
train = tf.train.AdamOptimizer(0.01).minimize(loss)

# Set the number of iterations
num_iterations = 1000

# Start the TensorFlow session
with tf.Session() as sess:
    # Initialize all the TensorFlow variables
    sess.run(tf.global_variables_initializer())

    # For every iteration
    for i in range(num_iterations):
        # Initialize an empty list for storing the states, actions, and rewards obtained in the episode
        episode_states, episode_actions, episode_rewards = [],[],[]
        # Set done to False
        done = False
        # Initialize the Return
        Return = 0
        # Initialize the state by resetting the environment
        state_whole = env.reset()
        state = state_whole[0]

        # While the episode is not over
        while not done:
            # Reshape the state
            state = state.reshape([1,4])
            # Feed the state to the policy network and the network returns the probability distribution over the action space as output, which becomes our stochastic policy π
            pi = sess.run(prob_dist, feed_dict={state_ph: state})
            # Select an action using this stochastic policy
            a = np.random.choice(range(pi.shape[1]), p=pi.ravel())
            # Perform selected action
            next_state, reward, done, _, info = env.step(a)
            # Render the environment
            # env.render()
            # Update the return
            Return += reward
            # One-hot encode the action
            action = np.zeros(num_actions)
            action[a] = 1
            # Store the state, action, and reward in their respective lists
            episode_states.append(state)
            episode_actions.append(action)
            episode_rewards.append(reward)
            # Update the state to the next state
            state = next_state

        # Compute the discounted and normalized reward
        discounted_rewards = discount_and_normalize_rewards(episode_rewards)

        # Define the feed dictionary
        feed_dict = {
            # Converts the list of episode states and actions (episode_states, episode_actions) into a numpy array and then vertically stacks them to
            # create a matrix. This matrix is then used to feed the state data into the neural network.
            state_ph: np.vstack(np.array(episode_states)),
            action_ph: np.vstack(np.array(episode_actions)),
            # Is a numpy array containing the discounted rewards for each time step in the episode.
            # This array is used to feed the discounted rewards data into the neural network.
            discounted_rewards_ph: discounted_rewards
        }

        # Train the network
        loss_, _ = sess.run([loss, train], feed_dict=feed_dict)

        # Print the return for every 10 iterations
        if i % 10 == 0:
            print("Iteration:{}, Return: {}".format(i, Return))

env.close()
