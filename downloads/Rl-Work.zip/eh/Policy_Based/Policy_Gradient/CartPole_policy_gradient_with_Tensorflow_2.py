import tensorflow as tf
import numpy as np
import gym

# Create the cart pole environment using gym
env = gym.make('CartPole-v1')

# Get the state shape
state_shape = env.observation_space.shape[0]

# Get the number of actions
num_actions = env.action_space.n

# Set the discount factor, gamma
gamma = 0.95


# Define discount_and_normalize_rewards for computing the discounted and normalized rewards
def discount_and_normalize_rewards(episode_rewards):
    # Initialize an array for storing the discounted rewards
    discounted_rewards = np.zeros_like(episode_rewards)

    # Compute the discounted reward
    reward_to_go = 0.0
    for i in reversed(range(len(episode_rewards))):
        reward_to_go = reward_to_go * gamma + episode_rewards[i]
        discounted_rewards[i] = reward_to_go

    # Normalize and return the reward
    discounted_rewards -= np.mean(discounted_rewards)
    discounted_rewards /= np.std(discounted_rewards)
    return discounted_rewards


# Define the policy network using the Keras API
model = tf.keras.Sequential([
    tf.keras.layers.Dense(32, activation='relu', input_shape=(state_shape,)),
    tf.keras.layers.Dense(num_actions)
])

# Define the optimizer
optimizer = tf.keras.optimizers.Adam(0.01)


# Define the training step
def train_step(states, actions, discounted_rewards):
    with tf.GradientTape() as tape:
        # Forward pass
        logits = model(states)
        # Compute the negative log policy
        neg_log_policy = tf.nn.sparse_softmax_cross_entropy_with_logits(logits=logits, labels=actions)
        # Compute the loss
        loss = tf.reduce_mean(neg_log_policy * discounted_rewards)

    # Compute gradients
    grads = tape.gradient(loss, model.trainable_variables)
    # Apply gradients
    optimizer.apply_gradients(zip(grads, model.trainable_variables))
    return loss


# Set the number of iterations
num_iterations = 1000

# For every iteration
for i in range(num_iterations):
    # Initialize an empty list for storing the states, actions, and rewards obtained in the episode
    episode_states, episode_actions, episode_rewards = [], [], []
    # Set done to False
    done = False
    # Initialize the Return
    Return = 0
    # Initialize the state by resetting the environment
    whole_state = env.reset()
    state = whole_state[0]
    # While the episode is not over
    while not done:
        # Reshape the state
        state = state.reshape([1, 4])
        # Feed the state to the policy network and the network returns the probability distribution over the action space as output, which becomes our stochastic policy π
        logits = model(state)
        # Sample an action from the policy
        action_probs = tf.nn.softmax(logits).numpy()[0]
        action = np.random.choice(num_actions, p=action_probs)
        # Perform selected action
        next_state, reward, done, _, info = env.step(action)
        # Update the return
        Return += reward
        # Store the state, action, and reward in their respective lists
        episode_states.append(state)
        episode_actions.append(action)
        episode_rewards.append(reward)
        # Update the state to the next state
        state = next_state


    # Compute the discounted and normalized reward
    discounted_rewards = discount_and_normalize_rewards(episode_rewards)

    # Define the inputs for training
    states = np.vstack(episode_states)
    actions = np.array(episode_actions)

    # Train the network
    loss = train_step(states, actions, discounted_rewards)

    # Print the return for every 10 iterations
    if i % 10 == 0:
        print("Iteration:{}, Return: {}".format(i, Return))

env.close()
