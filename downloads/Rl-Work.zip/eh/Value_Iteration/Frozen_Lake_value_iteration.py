import gym
import numpy as np

env = gym.make("FrozenLake-v1", is_slippery=True, render_mode="human")

def value_iteration(env):
    """
    Compute the optimal value function iteratively by taking the maximum over the Q function,
    Equation: V*(s) = max(a) Q*(s,a)
    """
    num_iteration = 1000

    # Threshold number for checking the convergence of the value function:
    threshold = 1e-20

    # Set the discount factor γ
    gamma = 1.0

    # Initialize the value table by setting the value of all states to zero
    value_table = np.zeros(env.observation_space.n)

    for i in range(num_iteration):
        # Update the value table, we use the updated value table (state values) from the previous iteration
        updated_value_table = np.copy(value_table)

        # Compute the Q_values of all the actions
        for s in range(env.observation_space.n):
            Q_values = []
            for a in range(env.action_space.n):
                value = 0
                for prob, next_state, reward, _ in env.P[s][a]:
                    updated_value = updated_value_table[next_state]
                    value += prob * (reward + gamma * updated_value)
                Q_values.append(value)

            # Update the value of the state as a maximum Q value, V*(s) = max(a) Q*(s,a)
            value_table[s] = max(Q_values)

        if np.sum(np.fabs(updated_value_table - value_table)) <= threshold:
            break

    return value_table


def extract_policy(value_table):
    # Set discount factor y
    gamma = 1

    # Initialize the policy with zeros, that is, we set the actions for all the states to be zero
    policy = np.zeros(env.observation_space.n)

    # Compute the Q value of all the actions in the state
    for s in range(env.observation_space.n):
        Q_values = []
        for a in range(env.action_space.n):
            value = 0
            for prob, next_state, reward, _ in env.P[s][a]:
                updated_value = value_table[next_state]
                value += prob * (reward + gamma * updated_value)
            Q_values.append(value)


        # Extract the policy by selecting the action that has the maximum Q value. π* = arg max(a) Q(s,a)
        policy[s] = np.argmax(np.array(Q_values))

    return policy



env.reset()


optimal_value_function = value_iteration(env)
optimal_policy = extract_policy(optimal_value_function)
print(optimal_policy)

env.render()
env.close()