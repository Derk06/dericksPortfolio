"""
Monte Carlo Tic-Tac-Toe Player
"""

import random
import poc_ttt_gui
import poc_ttt_provided as provided

# Constants for Monte Carlo simulator
# Change as desired
NTRIALS = 1000  # Number of trials to run
MCMATCH = 2.0  # Score for squares played by the machine player
MCOTHER = 1.0  # Score for squares played by the other player

# Add your functions here.


def mc_trial(board, player):
    """
    plays a complete game given the current board and the player to move
    """
    current_player = player
    while board.check_win() is None:
        empty_squares = board.get_empty_squares()  # Get a list of empty squares on the board
        random_square = random.choice(empty_squares)  # Choose a random empty square
        board.move(random_square[0], random_square[1], current_player)  # Make a move on the board
        current_player = provided.switch_player(current_player)  # Switch to the other player


def mc_update_scores(scores, board, player):
    """
    score the board and update the grid
    """
    winner = board.check_win()  # Check who is the winner of the game
    for row in range(board.get_dim()):
        for col in range(board.get_dim()):
            if board.square(row, col) == player and winner == player:
                scores[row][col] += MCMATCH  # Add score for squares played by the machine player
            elif board.square(row, col) == player and winner == provided.DRAW:
                scores[row][col] += MCOTHER  # Add score for squares played by the other player
            elif board.square(row, col) != player and winner == provided.DRAW:
                scores[row][col] -= MCOTHER  # Subtract score for squares played by the other player
            elif board.square(row, col) != player and winner != player:
                scores[row][col] -= MCMATCH  # Subtract score for squares played by the machine player
    return scores  # Return the updated scores matrix


def get_best_move(board, scores):
    """
    return one of the squares with the maximum score
    In the get_best_move function, max_score = float('-inf') initializes the variable max_score to negative infinity.
    By setting max_score to negative infinity initially, the function ensures that any
    valid score in the scores matrix (representing the scores for each square on the board)
    will be greater than max_score on the first comparison.
    This allows the function to correctly update max_score to the actual maximum score
    found in the scores matrix during subsequent iterations.
    In simpler terms, this initialization ensures that max_score starts at a
    value that will always be less than or equal to any valid score in the matrix,
    so that it can be updated correctly as the function iterates over the scores.
    """
    max_score = float('-inf')  # Initialize maximum score to negative infinity
    best_moves = []  # Initialize list of best moves
    for row in range(board.get_dim()):
        for col in range(board.get_dim()):
            if scores[row][col] > max_score and board.square(row, col) == provided.EMPTY:
                max_score = scores[row][col]  # Update maximum score
                best_moves = [(row, col)]  # Reset list of best moves
            elif scores[row][col] == max_score and board.square(row, col) == provided.EMPTY:
                best_moves.append((row, col))  # Add square to list of best moves
    return random.choice(best_moves)  # return a random move from the list of best moves


def mc_move(board, player, trials):
    """
    returns a move for the machine player
    """
    scores = []
    for dummy_row in range(board.get_dim()):
        row = []
        for dummy_col in range(board.get_dim()):
            row.append(0.0)  # Changing the matrix to a float allows for more precise scoring and evaluation of moves.
        scores.append(row)  # This will initialize the score and looks like [[0,0,0], [0,0,0], [0,0,0]]
    for dummy_trial in range(trials):
        trial_board = board.clone()  # Create a clone of the current board
        mc_trial(trial_board, player)  # Play a trial game
        mc_update_scores(scores, trial_board, player)  # Update scores based on trial game
    return get_best_move(board, scores)  # Return the best move based on scores


# Test game with the console or the GUI.
# Uncomment whichever you prefer.
# Both should be commented out when you submit for
# testing to save time.

DIMENSION = 3
BOARD = provided.TTTBoard(DIMENSION)
PLAYER = provided.PLAYERX

# provided.play_game(mc_move, NTRIALS, False)

# poc_ttt_gui.run_gui(DIMENSION, PLAYER, mc_move, NTRIALS, False)
