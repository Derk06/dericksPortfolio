# Python program for implementation of MergeSort
from arithmetic_tree import ArithmeticExpression
import draw_tree
from tree import Tree

tree_listleft = []
tree_listright = []

def mergeSort(arr):
    if len(arr) > 1:
        left_arr = arr[:len(arr)//2]
        right_arr = arr[len(arr)//2:]
        tree_listleft.append(left_arr)
        tree_listright.append(right_arr)

        # recursion
        mergeSort(left_arr)
        mergeSort(right_arr)
        # merge
        i = 0 # left array index
        j = 0 # right array index
        k = 0 # merged array index
        while i < len(left_arr) and j < len(right_arr):
            if left_arr[i] < right_arr[j]:
                arr[k] = left_arr[i]
                i += 1
            else:
                arr[k] = right_arr[j]
                j += 1
            k += 1
        while i < len(left_arr):
            arr[k] = left_arr[i]
            i += 1
            k += 1
        while j < len(right_arr):
            arr[k] = right_arr[j]
            j += 1
            k += 1

arr = [12,8,2,17,5,10,96,4,1,100,14]
print("Given array is:", arr)
mergeSort(arr)
print("\nSorted array is:", arr, "\n")
print(f"Right: {tree_listright}")
print(f"Left: {tree_listleft}")


right_tree = []
left_tree = []
while len(tree_listright) != 1 and len(tree_listleft) != 1:
    joined = tree_listright[-1] + tree_listleft[-1]
    count = -2
    while True:
        if all(x in joined for x in tree_listright[count]):
            print(f"{tree_listleft[-1]} and {tree_listright[-1]} --> {tree_listright[count]}")

            if all(x in tree_listright[0] for x in joined):
                right_tree.append([tree_listleft[-1], tree_listright[-1], tree_listright[count]])
            else:
                left_tree.append([tree_listleft[-1], tree_listright[-1], tree_listright[count]])
            tree_listright.pop()
            tree_listleft.pop()
            break

        elif all(x in joined for x in tree_listleft[count]):
            print(f"{tree_listleft[-1]} and {tree_listright[-1]} --> {tree_listleft[count]}")

            if all(x in tree_listleft[0] for x in joined):
                left_tree.append([tree_listleft[-1], tree_listright[-1], tree_listleft[count]])
            else:
                right_tree.append([tree_listleft[-1], tree_listright[-1], tree_listleft[count]])
            tree_listright.pop()
            tree_listleft.pop()
            break
        else:
            count += -1

arr = [12,8,2,17,5,10,96,4,1,100,14]

combined = []
while len(right_tree) != 1:
    if len(right_tree[0][0]) == 1 and len(right_tree[0][1]) == 1:
        left = ArithmeticExpression(right_tree[0][0], [])
        right = ArithmeticExpression(right_tree[0][1], [])
        combined_right = ArithmeticExpression(right_tree[0][2], [left, right])
        combined.append([combined_right, right_tree[0][2]])
        right_tree.pop(0)
    elif len(right_tree[0][0]) == 1:
        left = ArithmeticExpression(right_tree[0][0], [])
        match_found = False
        for index, _ in enumerate(combined):
            if all(x in combined[index][1] for x in right_tree[0][1]):
                right = combined[index][0]
                combined_right = ArithmeticExpression(right_tree[0][2], [left, right])
                combined.append([combined_right, right_tree[0][2]])
                del combined[index]
                right_tree.pop(0)
                match_found = True
            if match_found == True:
                break
    elif len(right_tree[0][1]) == 1:
        left = ArithmeticExpression(right_tree[0][1], [])
        match_found = False
        for index, _ in enumerate(combined):
            if all(x in combined[index][1] for x in right_tree[0][0]):
                right = combined[index][0]
                combined_right = ArithmeticExpression(right_tree[0][2], [left, right])
                combined.append([combined_right, right_tree[0][2]])
                del combined[index]
                right_tree.pop(0)
                match_found = True
            if match_found == True:
                break
    elif len(right_tree[0][1]) != 1 and len(right_tree[0][0]) != 1:
        match_found_left = False
        match_found_right = False
        left = None
        right = None
        for index, _ in enumerate(combined):
            if all(x in combined[index][1] for x in right_tree[0][0]):
                left = combined[index][0]
                del combined[index]
                match_found_left = True
            if match_found_left == True:
                break
        for index, _ in enumerate(combined):
            if all(x in combined[index][1] for x in right_tree[0][1]):
                right = combined[index][0]
                combined_right = ArithmeticExpression(right_tree[0][2], [left, right])
                combined.append([combined_right, right_tree[0][2]])
                del combined[index]
                right_tree.pop(0)
                match_found_right = True
            if match_found_right == True:
                break

combined_L_list = []
while len(left_tree) != 1:
    if len(left_tree[0][0]) == 1 and len(left_tree[0][1]) == 1:
        left = ArithmeticExpression(left_tree[0][0], [])
        right = ArithmeticExpression(left_tree[0][1], [])
        combined_left = ArithmeticExpression(left_tree[0][2], [left, right])
        combined_L_list.append([combined_left, left_tree[0][2]])
        left_tree.pop(0)
    elif len(left_tree[0][0]) == 1:
        left = ArithmeticExpression(left_tree[0][0], [])
        match_found = False
        for index, _ in enumerate(combined_L_list):
            if all(x in combined_L_list[index][1] for x in left_tree[0][1]):
                right = combined_L_list[index][0]
                combined_left = ArithmeticExpression(left_tree[0][2], [left, right])
                combined_L_list.append([combined_left, left_tree[0][2]])
                del combined_L_list[index]
                left_tree.pop(0)
                match_found = True
            if match_found == True:
                break
    elif len(left_tree[0][1]) == 1:
        left = ArithmeticExpression(left_tree[0][1], [])
        match_found = False
        for index, _ in enumerate(combined_L_list):
            if all(x in combined_L_list[index][1] for x in left_tree[0][0]):
                right = combined_L_list[index][0]
                combined_left = ArithmeticExpression(left_tree[0][2], [left, right])
                combined_L_list.append([combined_left, left_tree[0][2]])
                del combined_L_list[index]
                left_tree.pop(0)
                match_found = True
            if match_found == True:
                break
    elif len(left_tree[0][1]) != 1 and len(left_tree[0][0]) != 1:
        match_found_left = False
        match_found_right = False
        left = None
        right = None
        for index, _ in enumerate(combined_L_list):
            if all(x in combined_L_list[index][1] for x in left_tree[0][0]):
                left = combined_L_list[index][0]
                del combined_L_list[index]
                match_found_left = True
            if match_found_left == True:
                break
        for index, _ in enumerate(combined_L_list):
            if all(x in combined_L_list[index][1] for x in left_tree[0][1]):
                right = combined_L_list[index][0]
                combined_left = ArithmeticExpression(left_tree[0][2], [left, right])
                combined_L_list.append([combined_left, left_tree[0][2]])
                del combined_L_list[index]
                left_tree.pop(0)
                match_found_right = True
            if match_found_right == True:
                break

print(combined)
right_branch = ArithmeticExpression(tree_listright[0], [combined[0][0], combined[1][0]])
left_branch = ArithmeticExpression(tree_listleft[0], [combined_L_list[0][0], combined_L_list[1][0]])
mergesort_tree = ArithmeticExpression(arr, [right_branch, left_branch])
draw_tree.TreeDisplay(mergesort_tree)
print("finished")